import re,datetime

ANSI=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')

LINE=re.compile(r'^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z) (.*)$')

ASSERT=re.compile(r'^ROUTED_(?:COPILOT_INFERENCE|COPILOT_EFFORT_INFERENCE|MULTI_CANDIDATE_INFERENCE|COPILOT_CLI|NATIVE_INFERENCE)=passed(?: |$)')

def date(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))

def parse(raw):
 rows=[];depth=0;source_depth=None
 for n,line in enumerate(raw.decode('utf-8-sig').splitlines(),1):
  m=LINE.match(ANSI.sub('',line))
  if not m:continue
  t,s=m.groups()
  if s.startswith('##[group]'):
   depth+=1
   if s.startswith('##[group]Run '):source_depth=depth
   continue
  if s.startswith('##[endgroup]'):
   if source_depth is not None and depth==source_depth:source_depth=None
   depth=max(0,depth-1);continue
  if source_depth is not None:continue
  kind=None
  if ASSERT.match(s):kind='response_assertion_passed'
  elif s.startswith('ROUTED_SELECTION='):kind='routing_selection'
  elif s.startswith('[ERROR] Fatal error: InfrastructureReadinessError: Model routing failed'):kind='routing_startup_error'
  elif s.startswith('Process exiting with code: '):kind='application_exit'
  elif s.startswith('##[error]Process completed with exit code '):kind='workflow_step_exit_error'
  elif s.startswith('ROUTED_DEVIATION_EXIT='):kind='deviation_test_completion'
  if kind:rows.append({'line':n,'timestamp_utc':t,'kind':kind,'text':s})
 return rows

def selfcheck():
 lines=['##[group]Run cat << EOF','ROUTED_NATIVE_INFERENCE=passed provider=source','##[endgroup]','echo "ROUTED_NATIVE_INFERENCE=passed"','console.log("ROUTED_NATIVE_INFERENCE=passed");','ROUTED_NATIVE_INFERENCE=passed provider=runtime']
 b='\n'.join(f'2026-10-19T00:00:00.000000{i}Z {s}' for i,s in enumerate(lines)).encode()
 assert [e['line'] for e in parse(b)]==[6]
 return {'echoed_shell_and_program_source_excluded':True,'literal_heredoc_inside_command_group_excluded':True,'literal_runtime_assertion_retained':True}
