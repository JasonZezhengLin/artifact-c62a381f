from pathlib import Path
import sys,json,re,datetime,collections
R=Path(__file__).resolve().parent;O=R/'output';O.mkdir(exist_ok=True);sys.path[:0]=[str(R/'code'),str(R/'vendor')]
import yaml
from events import parse,date,selfcheck
selfcheck();jobs=json.loads((R/'data/jobs.json').read_text());runs=json.loads((R/'data/runs.json').read_text());assert len(jobs)==89 and len(runs)==77
profiles={};source_bodies=set()
for x in runs:
 b=(R/f"data/workflows/run_{x['run_number']}.yml").read_bytes();source_bodies.add(b);doc=yaml.load(b.decode(),Loader=yaml.BaseLoader);profiles[x['run_number']]=doc
selected={'Run router/API-proxy planning smoke','Run a routed Copilot inference through AWF','Run an effort-routed Copilot inference through AWF','Route between two Copilot candidates and enforce the choice','Run the Copilot CLI agent on the routed selection','Route between two Copilot candidates and allow a deviating choice','Assert preserved routing selection and terminal request records','Translate cross-endpoint Copilot sub-agent requests through AWF'}
exposure=[];events=[];same=[];eff=[];positive=0;main_jobs=0
for j in jobs:
 raw=(R/f"data/raw/job_{j['job_id']}.log").read_bytes();ev=parse(raw)
 for e in ev:e['candidate_step_numbers']=[s['number']for s in j['steps']if s.get('started-at')and s.get('completed-at')and date(s['started-at'])<=date(e['timestamp_utc'])<=date(s['completed-at'])+datetime.timedelta(seconds=1)]
 positive+=sum(e['kind']=='response_assertion_passed'for e in ev);failed={s['number']:s for s in j['failed_steps']};hits=[e for e in ev if e['kind']=='response_assertion_passed'and len(e['candidate_step_numbers'])==1 and e['candidate_step_numbers'][0]in failed and date(failed[e['candidate_step_numbers'][0]]['started-at'])<date(e['timestamp_utc'])<date(failed[e['candidate_step_numbers'][0]]['completed-at'])]
 for e in hits:same.append({'run_number':j['run_number'],'job_id':j['job_id'],'failed_step':failed[e['candidate_step_numbers'][0]],'positive_witness':e})
 specs=profiles[j['run_number']]['jobs']['model-routing']['steps']
 if any('ROUTED_COPILOT_EFFORT_INFERENCE=passed'in e['text']for e in hits):
  fs=next(s for s in j['failed_steps']if s['name']=='Run an effort-routed Copilot inference through AWF');script=next(s['run']for s in specs if s.get('name')==fs['name']);assert 'for effort in none max; do'in script
  def witnesses(rx):
   out=[]
   for no,line in enumerate(raw.decode('utf-8-sig').splitlines(),1):
    clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',line);m=re.match(r'^(\d{4}-\d\d-\d\dT\S+Z) (.*)$',clean)
    if m and re.fullmatch(rx,m[2])and date(fs['started-at'])<date(m[1])<date(fs['completed-at']):out.append({'line':no,'timestamp_utc':m[1],'text':m[2]})
   return out
  none=witnesses(r'COPILOT_EFFORT_INFERENCE=passed effort=none');http=witnesses(r'curl: \(22\) The requested URL returned error: 400');mx=witnesses(r'COPILOT_EFFORT_INFERENCE=passed effort=max');base=next(e for e in hits if 'ROUTED_COPILOT_EFFORT_INFERENCE=passed'in e['text']);assert len(none)==len(http)==1 and not mx and base['line']<none[0]['line']<http[0]['line'];eff.append({'run_number':j['run_number'],'job_id':j['job_id'],'base_response_pass':base,'explicit_none_pass':none[0],'following_HTTP_400':http[0],'max_pass_observed':False})
 actual={s['name']:s for s in j['steps']}
 if 'Run router/API-proxy planning smoke'in actual:
  main_jobs+=1;assert len(actual)==len(j['steps']);assert all(s.get('continue-on-error')in(None,'false',False)for s in specs)
  for i,s in enumerate(specs,1):
   name=s.get('name')
   if name not in selected:continue
   a=actual[name];before=[x for x in j['steps']if int(x['number'])<int(a['number'])and x['conclusion']=='failure'];gated=a['conclusion']=='skipped'and s.get('if')in(None,'')and bool(before);exposure.append({'run_number':j['run_number'],'job_id':j['job_id'],'name':name,'conclusion':a['conclusion'],'failure_gated_skip':gated,'earlier_failed_steps':[x['name']for x in before]})
 events.append({'run_number':j['run_number'],'job_id':j['job_id'],'events':ev})
codebook=json.loads((R/'data/source_coding.json').read_text());anchors=0
for row in codebook['rows']:
 texts=[]
 for n in row['run_numbers']:
  source=next(s.get('run','')for s in profiles[n]['jobs']['model-routing']['steps']if s.get('name')==row['step_name']);texts.append(source)
 assert len(set(texts))==1;lines=texts[0].splitlines()
 for a in row['source_anchor_lines']:assert lines[a['line']-1]==a['source'];anchors+=1
r={'runs':len(runs),'linked_job_resources':len(jobs),'raw_logs':len(events),'unique_YAML_bodies':len(source_bodies),'response_assertions':positive,'strict_inside_failed_step_witnesses':len(same),'ordered_effort_cases':len(eff),'main_jobs':main_jobs,'selected_test_step_instances':len(exposure),'failure_gated_skips':sum(x['failure_gated_skip']for x in exposure),'coded_source_bodies':len(codebook['rows']),'source_anchors':anchors,'new_model_inference_calls':0}
assert r['unique_YAML_bodies']==24 and positive==220 and len(same)==32 and len(eff)==27 and main_jobs==77 and len(exposure)==417 and r['failure_gated_skips']==101 and {x['run_number']for x in eff}==set(range(30,57))
for name,value in [('results',r),('events',events),('within_failed_step',same),('ordered_cases',eff),('exposure',exposure)]:(O/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(r))
